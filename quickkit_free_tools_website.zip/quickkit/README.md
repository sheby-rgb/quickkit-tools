# QuickKit starter website

## Included
- `index.html`: responsive single-page site
- Image compressor: runs in the browser using Canvas
- PDF merger: uses PDF-Lib from a CDN

## Run locally
Open `index.html` in a modern browser. The PDF merger needs an internet connection to load PDF-Lib.

## Publish for free
You can publish this static site with GitHub Pages or Cloudflare Pages. Create a repository, upload `index.html`, and enable the host's static-site deployment.

## Before public launch
- Check the brand name and domain availability before using the name commercially.
- Add a real privacy policy, contact page and terms appropriate to your location.
- Test all tools on mobile and desktop, with large files and different browsers.
- Add more original tools and genuinely helpful written guides.
- Do not promise that every file type or every PDF will work.
- Advertising and payment accounts may have age requirements; a parent/guardian may need to manage them. Earnings are not guaranteed.
